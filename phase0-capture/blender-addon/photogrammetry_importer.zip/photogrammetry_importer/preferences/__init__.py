""" Contains persistent addon preferences. """
